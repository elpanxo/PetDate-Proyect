package cl.PetDate.ms_mascotas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsMascotasApplicationTests {

	@Test
	void contextLoads() {
	}

}
